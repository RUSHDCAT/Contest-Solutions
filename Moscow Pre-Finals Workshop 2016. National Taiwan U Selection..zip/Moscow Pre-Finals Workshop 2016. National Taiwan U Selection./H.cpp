#include <bits/stdc++.h>
using namespace std;
typedef long long LL;
const int N = 80000 + 10;
const int mod = 1e6 + 3;
typedef long double LD;
const LD PI = acos(-1);
struct Complex {
    LD x, y;
    Complex(LD x=0.0, LD y=0.0) : x(x), y(y) {}
    Complex operator + (const Complex &b) const {
        return Complex(x+b.x, y+b.y);
    }
    Complex operator - (const Complex &b) const {
        return Complex(x-b.x, y-b.y);
    }
    Complex operator * (const Complex &b) const{
        return Complex(x * b.x - y * b.y, x * b.y + y * b.x);
    }
} x1[N<<2], x2[N<<2];
void change(Complex y[], int len) {
    for(int i=1,j=len/2;i<len-1;i++){
        if(i<j) swap(y[i], y[j]);
        int k=len/2;
        while (j>=k) {
            j-=k; k/=2;
        }
        if(j<k) j+=k;
    }
}
void fft(Complex y[], int len, int on){
    change(y, len);
    for(int h=2;h<=len;h<<=1) {
        Complex wn(cos(-on*2*PI/h), sin(-on*2*PI/h));
        for(int j=0;j<len;j+=h){
            Complex w(1,0);
            for(int k=j;k<j+h/2;k++) {
                Complex u=y[k];
                Complex t=w*y[k+h/2];
                y[k]=u+t;
                y[k+h/2]=u-t;
                w=w*wn;
            }
        }
    }
    if (on==-1) for(int i=0;i<len;i++) y[i].x /= len;
}
void mul(int *p, int& dp, int* q, int& dq) {
	for(int i=0;i<dp;i++) {
		assert(p[i] >= 0 && p[i] < mod);
		assert(q[i] >= 0 && q[i] < mod);
	}
    int len=1;
    while(len<=dp+dq) len<<=1;
    for(int i=0;i<dp;i++) x1[i]=Complex(p[i],0);
    for(int i=dp;i<len;i++) x1[i]=Complex(0,0);
    for(int i=0;i<dq;i++) x2[i]=Complex(q[i],0);
    for(int i=dq;i<len;i++) x2[i]=Complex(0,0);
    fft(x1,len,1);
    fft(x2,len,1);
    for(int i=0;i<len;i++) x1[i]=x1[i]*x2[i];
    fft(x1,len,-1);
    dp+=dq;
    for(int i=0;i<dp;i++) {
    	//printf("%.2Lf ", x1[i].x);
    	p[i]=(LL)(x1[i].x+0.5)%mod;
    }
    printf("\n");
}

int n, p, m;
LL pw[N];


vector<int> transfrom(vector<int> v, int k) {
	vector<int> vec; 
	vec.resize(m); 
	for(int i=0;i<m;i++){
		vec[1LL * i * pw[k] % m] = v[i];
	}
	return vec;
}
vector<int> init() {
	vector<int> res;
	res.resize(m); for(int i=0;i<m;i++) res[i]=0;
	for(int i=0;i<26;i++){
		for(int j=0;j<26;j++){
			res[((i-j)%m+m)%m] ++;
		}
	}

	return res;
}
int P, dp[N], q, dq[N];
vector<int> pro(vector<int> v1, vector<int> v2) {
	P=v1.size(); for(int i=0;i<v1.size();i++) dp[i] = v1[i];
	q=v2.size(); for(int i=0;i<v2.size();i++) dq[i] = v2[i];
	for(int i=0;i<v1.size();i++) printf("%d ", dp[i]); printf("\n");
	for(int i=0;i<v2.size();i++) printf("%d ", dq[i]); printf("\n");
	mul(dp, P, dq, q);
	vector<int> res; res.resize(m); for(int i=0;i<m;i++)res[i]=0;
	for(int i=0;i<2*m;i++) printf("%d ", dp[i]); printf("\n");
	for(int i=0;i<2*m;i++) (res[i%m] += dp[i]) %= mod;
	return res;
}
vector<int> solve(int l,int r) {
	if(l==r) {
		return init();
	}
	int len=(r-l+1);
	int mid=(l+r)>>1;
	if(len % 2 == 0) {
		vector<int> lef = solve(l,mid);
		vector<int> rig = transfrom(lef, len / 2);
		return pro(lef, rig);
	}
	vector<int> lef = solve(l,mid-1);
	vector<int> rig = transfrom(lef, (len+1)/2);
	vector<int> mid_ = transfrom(init(), mid-l+1);
	return pro(pro(lef,rig), mid_);
}


int main() {
	scanf("%d%d%d",&n,&m,&p);
	int PP = 1;
	for(int i=1;i<=n;i++) PP = (1LL * PP * 26) % mod;
	pw[0] = 1; for(int i=1;i<N;i++) pw[i]=pw[i-1] * p % m;
	vector<int> ans = solve(1,n);
	LL res = (1LL * (ans[0] - PP) % mod + mod) % mod  * ((mod + 1) / 2) % mod;
	printf("%lld\n", res);
}